def hola(): 
    return 'Hola desde paquete_demo'